# YAML Review Evidence Template

## Triage Notes And False Leads

- Triage notes reviewed:
- False leads ruled out:
- Strongest RBAC clue:
- Strongest workload/credential clue:

## Manifest Inventory Evidence

- Reviewed manifest:
- Resource kinds:
- Namespaces:
- Cluster-scoped resources:
- Dry-run or parse-check output:

## Security Blocker Evidence

- Secret access evidence:
- Privileged container evidence:
- hostPath mount evidence:
- Committed credential placeholder:
- Risk category for each blocker:

## Vendor Decision Evidence

- Local manifest risk analyzer result:
- Block or approve decision:
- Required safer baseline changes:
- Questions back to vendor:
- Validation output:
- Cleanup or no-live-apply note:
