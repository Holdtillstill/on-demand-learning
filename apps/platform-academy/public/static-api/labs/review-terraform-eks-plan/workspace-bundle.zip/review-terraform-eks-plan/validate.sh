#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="$DIR/artifacts/labs/platform-academy/review-terraform-eks-plan/validate.sh"

if [[ ! -f "$TARGET" ]]; then
  echo "FAIL: copied validator is missing: $TARGET" >&2
  exit 1
fi

use_default_evidence=true
for arg in "$@"; do
  case "$arg" in
    --files-only|--evidence)
      use_default_evidence=false
      ;;
  esac
done

args=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --files-only)
      shift
      ;;
    *)
      args+=("$1")
      shift
      ;;
  esac
done

if [[ "$use_default_evidence" == true ]]; then
  args=("--evidence" "$DIR/evidence.md" "${args[@]}")
fi

bash "$TARGET" "${args[@]}"
