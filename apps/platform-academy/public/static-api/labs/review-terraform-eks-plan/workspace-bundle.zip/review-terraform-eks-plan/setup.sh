#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="$DIR/artifacts/labs/platform-academy/review-terraform-eks-plan/setup.sh"
TEMPLATE="$DIR/artifacts/labs/platform-academy/review-terraform-eks-plan/evidence-template.md"

use_default_evidence=true
help_requested=false
for arg in "$@"; do
  case "$arg" in
    --evidence)
      use_default_evidence=false
      ;;
    -h|--help)
      use_default_evidence=false
      help_requested=true
      ;;
  esac
done

if [[ -f "$TARGET" ]]; then
  args=("$@")
  if [[ "$use_default_evidence" == true ]]; then
    args=("--evidence" "$DIR/evidence.md" "${args[@]}")
  fi
  bash "$TARGET" "${args[@]}"
  if [[ "$help_requested" == false ]]; then
    echo
    echo "From this extracted workspace, continue with:"
    echo "  ./validate.sh --files-only"
    echo "  ./validate.sh"
    echo "  ./cleanup.sh"
  fi
else
  if [[ -s "$DIR/evidence.md" ]]; then
    echo "Evidence note already exists: $DIR/evidence.md"
  elif [[ -f "$TEMPLATE" ]]; then
    cp "$TEMPLATE" "$DIR/evidence.md"
    echo "Created evidence note: $DIR/evidence.md"
  else
    echo "No setup script or evidence template found for review-terraform-eks-plan; create $DIR/evidence.md before validation." >&2
    exit 1
  fi

  echo
  echo "Next:"
  echo "  Edit evidence.md with your investigation notes."
  echo "  ./validate.sh --files-only"
  echo "  ./validate.sh"
fi
