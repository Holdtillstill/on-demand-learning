#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="$DIR/artifacts/labs/platform-academy/debug-aws-alb-health-path/cleanup.sh"

if [[ ! -f "$TARGET" ]]; then
  echo "FAIL: copied cleanup script is missing: $TARGET" >&2
  exit 1
fi

bash "$TARGET" "$@"
